#!/usr/bin/env python3
#--------------publicador de Float64--------------
import rospy
from geometry_msgs.msg import Point
from geometry_msgs.msg import Twist


#el codigo se identifica ante ros
rospy.init_node('codigo2_pub', anonymous=True)


joint1_value = 0.0
joint2_value = 0.0
joint3_value = 0.0
joint4_value = 0.0
joint5_value = 0.0
joint6_value = 0.0

def callback(data):
	#rospy.loginfo("I heard %d", data.x) #como print
	global joint1_value,joint2_value,joint3_value,joint4_value,joint5_value,joint6_value
	joint1_value = data.linear.x;
	joint2_value = data.linear.y;
	joint3_value = data.linear.z;
	joint4_value = data.angular.x;
	joint5_value = data.angular.y;
	joint6_value = data.angular.z;


sub = rospy.Subscriber("random_twist", Twist, callback)  
#se crea el publicador
pub1 = rospy.Publisher('random_point1', Point, queue_size=1)
pub2 = rospy.Publisher('random_point2', Point, queue_size=1)

rate = rospy.Rate(1) # 1hz --> 1/1hz=1s
while not rospy.is_shutdown():
   
    pointmessaje1 = Point(joint1_value, joint2_value, joint3_value)
    print(pointmessaje1)
    pub1.publish(pointmessaje1)
    pointmessaje2 = Point(joint4_value, joint5_value, joint6_value)
    print(pointmessaje2)
    pub2.publish(pointmessaje2)
    rate.sleep()    